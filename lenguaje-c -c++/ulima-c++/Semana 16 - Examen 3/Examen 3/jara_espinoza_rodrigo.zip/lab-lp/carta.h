#include <iostream>

class Carta
{
public:
    std::string nombre;
    int edad;
    std::string texto;
    float peso;
    bool estaEntregada; 

    Carta(std::string nombre, int edad, std::string texto, float peso, bool estaEntregada);
    virtual void Imprimir();
};

class CartaJugueteFisico : public Carta
{
public:
    std::string direccion;

    CartaJugueteFisico(std::string nombre, int edad, std::string texto, float peso, bool estaEntregada, std::string direccion);
    virtual void Imprimir() override;
};

class CartaJugueteDigital : public Carta
{
public:
    std::string email;
    std::string username;

    CartaJugueteDigital(std::string nombre, int edad, std::string texto, float peso, bool estaEntregada, std::string email, std::string username);
    virtual void Imprimir() override;
};