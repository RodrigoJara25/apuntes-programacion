#include "carta.h"

Carta::Carta(std::string nombre, int edad, std::string texto, float peso, bool estaEntregada)
        : nombre(nombre), edad(edad), texto(texto), peso(peso), estaEntregada(estaEntregada)
{}

void Carta::Imprimir()
{
    std::cout << "Nombre: " << this->nombre << '\n';
    std::cout << "Edad: " << this->edad << '\n';
    std::cout << "Texto: " << this->texto << '\n';
    std::cout << "Peso: " << this->peso << '\n';
}

// ======================= CARTA FISICA =================================
CartaJugueteFisico::CartaJugueteFisico(std::string nombre, int edad, std::string texto, float peso, bool estaEntregada, std::string direccion)
        : Carta(nombre, edad, texto, peso, estaEntregada), direccion(direccion)
{}

void CartaJugueteFisico::Imprimir()
{
    std::cout << "Nombre: " << this->nombre << '\n';
    std::cout << "Edad: " << this->edad << '\n';
    std::cout << "Texto: " << this->texto << '\n';
    std::cout << "Peso: " << this->peso << '\n';
    std::cout << "Direccion: " << this->direccion << '\n';
}

// ======================= CARTA DIGITAL =================================
CartaJugueteDigital::CartaJugueteDigital(std::string nombre, int edad, std::string texto, float peso, bool estaEntregada, std::string email, std::string username)
        : Carta(nombre, edad, texto, peso, estaEntregada), email(email), username(username)
{}

void CartaJugueteDigital::Imprimir()
{
    std::cout << "Nombre: " << this->nombre << '\n';
    std::cout << "Edad: " << this->edad << '\n';
    std::cout << "Texto: " << this->texto << '\n';
    std::cout << "Peso: " << this->peso << '\n';
    std::cout << "Email: " << this->email << '\n';
    std::cout << "Username: " << this->username << '\n';
}
