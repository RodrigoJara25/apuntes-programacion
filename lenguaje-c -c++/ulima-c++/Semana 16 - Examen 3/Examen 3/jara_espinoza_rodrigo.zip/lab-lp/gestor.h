#include "carta.h"
#include <iostream>
#include <vector>

class GestorCartas
{
    std::vector<Carta>* listaCartas;
    int indiceCartaActual;
    float pesoMaximo;
public:
    GestorCartas(float pesoMaximo);

    bool AgregarCarta(Carta* carta);
    Carta* BuscarCarta(std::string nombre);
    Carta* ObtenerCarta();
    void ImprimirReporte();
};
