#include "gestor.h"

GestorCartas::GestorCartas(float pesoMaximo)
        : pesoMaximo(pesoMaximo)
{}

bool GestorCartas::AgregarCarta(Carta *carta)
{
    if (carta->peso > this->pesoMaximo){
        listaCartas->push_back(*carta);
        return true;
    }
    return false;
}

Carta* GestorCartas::BuscarCarta(std::string nombre)
{
    for(auto& carta : *listaCartas)
    {
        if (carta.nombre == nombre)
        {
            return &carta;
        }
        
    }
    return nullptr;
}

Carta* GestorCartas::ObtenerCarta()
{   

    auto& carta_retornar = *listaCartas[indiceCartaActual];
    indiceCartaActual++;

    return carta_retornar;
}

void GestorCartas::ImprimirReporte()
{
    std::cout << "===================================" << '\n';
    std::cout << "REPORTE DE CARTAS DE PAPA NOEL" << '\n';
    std::cout << "===================================" << '\n';
    int count = 0;
    for (auto& carta : *listaCartas)
    {
        std::cout << "Carta 1" << '\n';
        carta.Imprimir();
        std::cout << '\n';
        if (carta.estaEntregada == false)
        {
            std::cout << "ENTREGADA" << '\n';
        }
        else{
            std::cout << "ENTREGADA" << '\n';
        }
    }
}
