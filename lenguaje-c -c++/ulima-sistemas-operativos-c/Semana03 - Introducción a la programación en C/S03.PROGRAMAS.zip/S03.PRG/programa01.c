/*
    Crear un programa que permita el
    ingreso de dos números enteros
    y muestre la suma
*/

#include <stdio.h>

int main()
{
    // Variables

    int a ; // Primer sumando
    int b ; // Segundo sumando
    int c ; // Resultado

    // Ingreso de datos

    printf("Digite primer número: ") ;
    scanf("%d", &a) ;
    printf("Digite segundo número: ") ;
    scanf("%d", &b) ;

    // Resultado

    c = a + b ;

    // Imprimir Resultado

    printf("Resultado: %d\n", c) ;
    return 0 ;
}
