#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Declaracion de variables
    int a, r ;
    // Ingresar numeros en base 10
    system("clear") ;  // system("cls") para Windows
    printf("* Ingrese a: ") ; scanf("%d", &a) ;
    printf("\n") ;
    // Operaciones con bits
    r = a << 1 ;  // 01 bit hacia lado derecho
    printf("* a << 1 : ") ; printf(" (%d)\n", r) ;
    r = a << 2 ;  // 02 bits hacia lado derecho
    printf("* a << 2 : ") ; printf(" (%d)\n", r) ;
    r = a << 3 ;  // 03 bits hacia lado derecho
    printf("* a << 3 : ") ; printf(" (%d)\n", r) ;
    r = a << 4 ;  // 04 bits hacia lado derecho
    printf("* a << 4 : ") ; printf(" (%d)\n", r) ;
    r = a << 5 ;  // 05 bits hacia lado derecho
    printf("* a << 5 : ") ; printf(" (%d)\n", r) ;

    return 0 ;
}

