/*
    EJERCICIO: Hallar el área de un círculo
*/

#include <stdio.h>
#include <stdlib.h>

#define PI 3.141592

int main()
{
    // Variables
    float radio, area ;

    // Limpiar pantalla
    system("clear") ; // Linux acepta comando 'clear'

    // Lectura de datos
    printf("* Digite radio: ") ; scanf("%f", &radio) ;

    // Obtener resultado
    area = PI*radio*radio ; // Sentencia de asignación

    // Mostrar en pantalla el resultado
    printf("\n") ;
    printf("* El circulo de radio %.3f tiene un area %.3f\n", radio, area) ;

    return(0);
}
