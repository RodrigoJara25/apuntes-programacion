#include <stdio.h>

int main()
{
  int a ;

  for( a = 0 ; a < 10 ; a++ )
  {
     puts("Repite 10 veces")
  }

  return(0) ;
}
