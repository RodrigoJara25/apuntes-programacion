/*
    EJERCICIO: Modificar el programa de tal manera
               que permita sumar dos numeros reales
               en precisiin simple
               * tipo de dato: float
               * formato: %f
               * salida: 3 digitos de precision
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Variables
    float a ; // Variable 'a'
    float b, r ; // Variables 'b' y 'r'
    
    // Limpiar pantalla
    system("clear") ; // Linux acepta comando 'clear'
    //system("cls") ; // Windows acepta comando 'cls'
    // Lectura de numeros
    printf("* Digite a: ") ;
    scanf("%f", &a) ;
    printf("* Digite b: ") ;
    scanf("%f", &b) ;
    // Obtener resultado
    r = a + b ; // Sentencia de asignacion
    // Mostrar en pantalla el resultado
    printf("\n") ;
    printf("* Resultado: %.3f\n", r) ;
    printf("* La suma %.3f y %.3f es %.3f\n", a, b, r) ;
    
    return(0);
}
