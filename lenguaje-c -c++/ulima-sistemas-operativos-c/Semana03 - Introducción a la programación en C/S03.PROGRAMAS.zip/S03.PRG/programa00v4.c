/*
    Ejemplo de hola mundo con comentario multilinea
*/

// Cabecera
#include <stdio.h>

// Cuerpo principal
int main()
{
    printf("Hola Mundo\n") ;
    printf("Hola Sistemas Operativos") ;

    return 0 ;
}
