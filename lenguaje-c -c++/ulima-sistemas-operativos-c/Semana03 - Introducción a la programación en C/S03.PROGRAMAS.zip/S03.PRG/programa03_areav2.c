/*
    EJERCICIO: Hallar el área de un círculo
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    // Variables
    double radio, area ;

    // Limpiar pantalla
    system("clear") ; // Linux acepta comando 'clear'

    // Lectura de datos
    printf("* Digite radio: ") ; scanf("%lf", &radio) ;

    // Obtener resultado
    area = M_PI*pow(radio,2) ; // Sentencia de asignación

    // Mostrar en pantalla el resultado
    printf("\n") ;
    printf("* El circulo de radio %lf tiene un area %.20lf\n", radio, area) ;

    return(0);
}
