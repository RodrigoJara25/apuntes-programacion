#include <stdio.h>

int main()
{
  int a ;

  printf("Pon un valor: ") ;
  scanf("%d",&a) ;

  if( a < 10 )
	  {
		puts("Pusiste un valor menor a 10") ;
		a -= 5 ;
		printf("El valor ahora es %d\n",a) ;
	  }

  printf("Gracias") ;
  
  return(0) ;
}
