#include <stdio.h>
#include <string.h>

int main ()
{
   char cadena01[12] = "Hola" ;
   char cadena02[12] = "Mundo" ;
   char cadena03[12] ;
   int  len ;


   /* copy str1 into str3 */
   strcpy(cadena03, cadena01) ;
   printf("strcpy( cadena03, cadena01) :  %s\n", cadena03 ) ;

   /* concatenates str1 and str2 */
   strcat( cadena01, cadena02) ;
   printf("strcat( cadena01, cadena02):   %s\n", cadena01) ;

   /* total lenghth of str1 after concatenation */
   len = strlen(cadena01) ;
   printf("strlen(cadena01) :  %d\n", len ) ;

   return 0 ;
}
