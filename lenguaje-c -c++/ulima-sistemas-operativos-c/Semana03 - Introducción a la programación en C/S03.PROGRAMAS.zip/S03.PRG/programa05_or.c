#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Declaracion de variables
    int a, b, r ;
    // Ingresar numeros en base 10
    system("clear") ;  // system("cls") para Windows
    printf("* Ingrese a: ") ; scanf("%d", &a) ;
    printf("* Ingrese b: ") ; scanf("%d", &b) ;
    printf("\n") ;
    // Operaciones con bits
    r = a | b ;
    // Resultados
    printf("* OR  : %d\n",r) ;
    printf("\n") ;

    return 0 ;
}

