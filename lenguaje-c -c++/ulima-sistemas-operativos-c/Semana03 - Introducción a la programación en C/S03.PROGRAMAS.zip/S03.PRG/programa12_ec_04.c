#include <stdio.h>

int main()
{
  int a ;
  printf ("Ingrese un valor: ") ;
  scanf ("%d",&a) ;
  do
  {
	    printf("A repetir\n") ;
      a-- ;
  }
  while (a > 0) ;

  return (0) ;
}
