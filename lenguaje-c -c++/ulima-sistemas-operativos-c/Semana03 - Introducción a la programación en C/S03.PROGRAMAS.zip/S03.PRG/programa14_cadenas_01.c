#include <stdio.h>

int main()
{
    char cadena01[] = "Saludos" ;
    char cadena02[50] = "Saludos" ;
    char cadena03[] = {'S','a','l','u','d','o','s','\0'} ;
    char cadena04[50] = {'S','a','l','u','d','o','s','\0'} ;
    return 0 ;
}
