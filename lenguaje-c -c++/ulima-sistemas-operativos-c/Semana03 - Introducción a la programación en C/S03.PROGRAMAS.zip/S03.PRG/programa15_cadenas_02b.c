#include <stdio.h>

int main()
{
    // Declarar e inicializar un cadena
    char cadena[50] ;
    // Leer una cadena en pantalla
    printf("Ingrese nombre: ") ;
    gets(cadena) ;
    // Mostrar una cadena en pantalla
    printf("Nombre: ") ;
    puts(cadena)  ;
    return 0 ;
}