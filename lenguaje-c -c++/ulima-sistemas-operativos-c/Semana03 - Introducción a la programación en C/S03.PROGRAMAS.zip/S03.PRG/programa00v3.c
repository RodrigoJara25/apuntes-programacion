/*
    Ejemplo de hola mundo con comentario multilinea
*/

// Cabecera
#include <stdio.h>

// Cuerpo principal
int main()
{
    printf("Hola Mundo") ;

    return 0 ;
}
