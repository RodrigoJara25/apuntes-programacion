#include <stdio.h>

int main()
{
    // Declarar e inicializar una cadena
    char cadena[50] ;
    // Leer una cadena en pantalla
    printf("Ingrese nombre: ") ;
    scanf("%s", cadena) ;
    // Mostrar una cadena en pantalla
    printf("Nombre: ") ;
    printf("%s\n", cadena)  ;
    return 0 ;
}
