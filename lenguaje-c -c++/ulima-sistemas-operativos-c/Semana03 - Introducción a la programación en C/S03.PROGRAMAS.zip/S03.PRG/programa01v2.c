#include <stdio.h>
#include <stdlib.h>

int main()
{
    // Variables
    int a ; // Variable 'a'
    int b, r ; // Variables 'b' y 'r'
    
    // Limpiar pantalla
    system("clear") ; // Linux acepta comando 'clear'
    //system("cls") ; // Windows acepta comando 'cls'
    // Lectura de números
    printf("* Digite a: ") ;
    scanf("%d", &a) ;
    printf("* Digite b: ") ;
    scanf("%d", &b) ;
    // Obtener resultado
    r = a + b ; // Sentencia de asignación
    // Mostrar en pantalla el resultado
    printf("\n") ;
    printf("* Resultado: %d\n", r) ;
    printf("* La suma %d y %d es %d\n", a, b, r) ;
    
    return(0) ;
}
