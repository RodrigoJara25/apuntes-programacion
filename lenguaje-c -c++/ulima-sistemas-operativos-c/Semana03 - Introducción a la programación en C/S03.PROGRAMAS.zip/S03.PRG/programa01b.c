/*
    Crear un programa que permita el
    ingreso de dos números enteros
    y muestre la suma
*/

#include <stdio.h>

int main()
{
    // Variables

    int  a, b, c ; // Sumandos y resultado

    // Ingreso de datos

    printf("Introduce dos enteros separados por un espacio:  ") ;
    scanf("%d %d", &a, &b) ;

    // Resultado

    c = a + b ;

    // Imprimir Resultado

    printf("La suma de %d y %d es %d\n", a, b, c) ;
    return 0 ;
}
