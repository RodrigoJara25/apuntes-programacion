#include "p3.h"

std::tuple<float, float, int> ObtenerDatos()
{
    std::cout << "Monto Capital: " << '\n';
    float capital;
    std::cin >> capital;
    std::cout << "Interes Mensual: " << '\n';
    float interes;
    std::cin >> interes;
    std::cout << "Meses: " << '\n';
    float meses;
    std::cin >> meses;

    std::tuple <float, float, int> tupla{capital, interes, meses};
    return tupla;
}

void ImprimirReporte(std::tuple<float, float, int> tupla)
{
    float capital = std::get<0> (tupla);
    float interes = std::get<1> (tupla);
    int meses = std::get<2> (tupla);
    for (int i = 0; i < meses; i++)
    {
        std::cout << "Mes: " << (i+1) << '\n';
        std::cout << "Capital: " << capital << '\n';
        float cant_interes = capital * interes;
        std::cout << "Intereses: " << cant_interes << '\n';
        capital = capital + cant_interes;
        std::cout << "Nuevo Capital: " << capital << '\n';
    }
    float interes_total = capital - std::get<0>(tupla);
    std::cout << "El interes total por recibir es de : " << interes_total << '\n';
}
