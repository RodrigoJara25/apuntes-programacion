#include <iostream>
#include <tuple>

std::tuple <float, float, int> ObtenerDatos();
void ImprimirReporte(std::tuple<float, float, int> tupla);