#include <iostream>
#include <tuple>
#include "p3.h"

int main()
{
    std::tuple<float, float, int> tupla = ObtenerDatos();
    ImprimirReporte(tupla);

    return 0;
}