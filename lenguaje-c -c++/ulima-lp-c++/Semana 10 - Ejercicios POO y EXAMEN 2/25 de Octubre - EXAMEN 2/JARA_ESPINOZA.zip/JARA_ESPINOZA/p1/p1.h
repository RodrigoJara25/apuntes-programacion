#include <iostream>
#include <array>

int SumarSi(std::array<int, 8> listaInt, std::array<bool, 8> listaBool);