#include "p1.h"

int SumarSi(std::array<int, 8> listaInt, std::array<bool, 8> listaBool)
{
    int suma = 0;
    for (int i = 0; i < listaBool.size(); i++)
    {
        if (listaBool[i] == true)
        {
            suma= suma + listaInt[i];
        }
    }
    return suma;
}