#include "p1.h"

int main()
{
    std::array <int, 8> listaInt = {3,6,2,1,7,9,8,5};
    std::array <bool, 8> listaBool = {false, true, false, false, true, false, false, true}; 
    int res = SumarSi(listaInt, listaBool);
    std::cout << "Resultado: " << res << '\n';
    return 0;
}