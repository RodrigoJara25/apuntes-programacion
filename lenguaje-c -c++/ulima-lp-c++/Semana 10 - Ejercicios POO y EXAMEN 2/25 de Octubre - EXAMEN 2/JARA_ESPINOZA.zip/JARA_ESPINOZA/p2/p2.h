#include <iostream>
#include <vector>

struct Pokemon
{
    std::string nombre;
    float health;
    float attack;
    float defense;
};

std::vector<Pokemon> ObtenerPokedex();
void ImprimirPokedex(std::vector<Pokemon> pokedex);
