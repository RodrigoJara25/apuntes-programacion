#include <iostream>
#include "p2.h"

int main()
{
    std::vector<Pokemon> listaPokemon = ObtenerPokedex();
    ImprimirPokedex(listaPokemon);
    return 0;
}
