#include "p2.h"

std::vector<Pokemon> ObtenerPokedex()
{
    std::cout << "CANTIDAD DE POKEMONES: " << '\n';
    int cant;
    std::cin >> cant;

    std::vector<Pokemon> listaPokemon;
    for (int i = 0; i < cant; i++)
    {
        std::cout << "INGRESAR DATOS DEL POKEMON: " << '\n';
        std::cout << "nombre: " << '\n';
        std::string nombre;
        std::cin >> nombre;
        std::cout << "health: " << '\n';
        float health;
        std::cin >> health;
        std::cout << "attack: " << '\n';
        float attack;
        std::cin >> attack;
        std::cout << "defense: " << '\n';
        float defense;
        std::cin >> defense;
        Pokemon p{nombre, health, attack, defense};
        listaPokemon.push_back(p);
    }
    
    return listaPokemon;
}

void ImprimirPokedex(std::vector<Pokemon> pokedex)
{
    for (auto [nombre, salud, ataque, defensa] : pokedex)
    {
        std::cout << "Nombre: " << nombre << '\n';
        std::cout << "Salud: " << salud << '\n';
        std::cout << "Ataque: " << ataque << '\n';
        std::cout << "Defensa: " << defensa << '\n';
    }
    float promedio_max = -1;
    float promedio_min = 1000;
    Pokemon p_max = {"nombre", 0, 0, 0};
    Pokemon p_min = {"nombre", 0, 0, 0};
    for (auto [nombre, salud, ataque, defensa] : pokedex)
    {
        if ((ataque + defensa)/2.0f >= promedio_max)
        {
            promedio_max = (ataque + defensa)/2.0f;
            p_max = {nombre, salud, ataque, defensa};
        }
        if ((ataque + defensa)/2.0f <= promedio_min)
        {
            promedio_min = (ataque + defensa)/2.0f;
            p_min = {nombre, salud, ataque, defensa};
        }
    }
    std::cout << "Nombre Pokemon Mayor: " << p_max.nombre << '\n';
    std::cout << "Nombre Pokemon Menor: " << p_min.nombre << '\n';    
    
}
