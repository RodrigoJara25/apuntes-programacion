#include "p0.h"

Personaje::Personaje(std::string nombre)
{
    this->nombre = nombre;
    this->salud = 100;
}

void Personaje::RecibirDanho()
{
    this->salud = this->salud - 1;
}
