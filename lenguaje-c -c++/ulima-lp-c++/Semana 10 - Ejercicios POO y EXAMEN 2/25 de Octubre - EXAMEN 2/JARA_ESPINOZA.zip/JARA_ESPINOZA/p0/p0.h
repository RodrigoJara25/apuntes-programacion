#include <iostream>

class Personaje
{
    std::string nombre;
public:
    float salud;
    Personaje(std::string nombre);
    void RecibirDanho();
};