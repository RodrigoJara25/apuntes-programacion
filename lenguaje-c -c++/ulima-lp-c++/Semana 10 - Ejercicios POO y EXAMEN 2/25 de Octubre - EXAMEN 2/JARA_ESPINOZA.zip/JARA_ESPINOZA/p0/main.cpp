#include <iostream>
#include "p0.h"

int main()
{
    Personaje p1("Rodrigo");
    std::cout << "Salud: " << p1.salud << '\n';
    p1.RecibirDanho();
    std::cout << "Salud: " << p1.salud;

    return 0;
}