/*
7.- (2 puntos). Escribir un programa que permita sumar los cuadrados de todos 
los números pares entre 1 y 100 a excepción de los números que terminen en 0. 
Puede utilizar funciones de la librería Math.
 */
package examen;

import java.util.Scanner;

public class Pregunta7 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        double suma = 0;
        
        for (int i = 1; i <= 100; i++) 
        {
            if (i%2==0 && i!=10 && i!=20 && i!=30 && i!=40 && i!=50 && i!=60 && i!=70 && i!=80 && i!=90 && i!=100) 
            {
                suma = suma + i*i;
                //System.out.println(i);
            }
        }
        System.out.println("La suma de los cuadrados de todos los números pares entre 1 y 100 a excepción de los números que terminen en 0 es " + suma);
        
        
        
    }
}
