/*
8.- (2 puntos). Escribir un programa que permita determinar si un año es bisiesto,
siguiendo la siguiente regla: son múltiplos de 4, pero los múltiplos de 100 no 
lo son, aunque los múltiplos de 400 sí. Escribir una función que reciba un año 
y retorne si es bisiesto.
 */
package examen;

import java.util.Scanner;

public class Pregunta8 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingresar un año: ");
        
        int año = entrada.nextInt();
        
        if (año%400==0) 
        {
            System.out.println("Es un año bisiesto");
        }
        else if (año%100==0)
        {
            System.out.println("No es un año bisiesto");
        }
        else if (año%4==0)
        {
            System.out.println("Es un año bisiesto");
        }
        else
        {
            System.out.println("No es un año bisiesto");
        }
    }
}
