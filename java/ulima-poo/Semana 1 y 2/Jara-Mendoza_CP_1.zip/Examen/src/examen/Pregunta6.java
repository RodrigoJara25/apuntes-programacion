/*
6.- (3 puntos) Realice un programa para determine la cantidad a pagar en una 
llamada telefónica, teniendo en cuenta lo siguiente:
•	Toda llamada que dure menos de 3 minutos tiene un costo de 1.8 sol por 
        minuto
•	Toda llamada que dure entre 3 y 10 minutos(inclusive) cuesta 1.5 por 
        minuto
•	Toda llamada que dure más de 10 minutos cuesta 1.2 por minuto

El programa finaliza cuando se ingresa como duración de llamada 0.

 */
package examen;

import java.util.Scanner;

public class Pregunta6 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingresar tiempo de la llamada en minutos: ");
        
        float min = entrada.nextFloat();
        
        while (min!=0)
        {
            if (min < 3) 
            {
                double costo = 1.8;
                
                double cant_pagar = min * costo;
                
                System.out.println("La cantidad a pagar es " + cant_pagar + " soles");
            }
            else if (min>=3 && min<=10)
            {
                double costo = 1.5;
                
                double cant_pagar = min * costo;
                
                System.out.println("La cantidad a pagar es " + cant_pagar + " soles");
            }   
            else
            {
                double costo = 1.2;
                
                double cant_pagar = min * costo;
                
                System.out.println("La cantidad a pagar es " + cant_pagar + " soles");
            }
            
            System.out.println("Ingresar tiempo de la llamada en minutos: ");
            
            min = entrada.nextFloat();
        }
    }
}
