package examen;
import java.util.Scanner;
       
public class Ejercicio1 {
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int venta = 1;
        double impuesto = 0;
        double mi = 0;
        double montofinal = 0;
        while (venta >= 0) {
            System.out.println("Ingrese el monto de la venta: ");
            venta = sc.nextInt();
            if(venta >= 50 && venta <= 100){
                impuesto = 0.065;
                mi = impuesto * venta;
                System.out.println("El impuesto es: " + mi);
                montofinal = venta + mi;
                System.out.println("El monto final es: " + montofinal);
            }
            if(venta >= 101 && venta <= 150){
                impuesto = 0.1;
                mi = impuesto * venta;
                System.out.println("El impuesto es: " + mi);
                montofinal = venta + mi;
                System.out.println("El monto final es: " + montofinal);
            }
            if(venta > 150){
                impuesto = 0.18;
                mi = impuesto * venta;
                System.out.println("El impuesto es: " + mi);
                montofinal = venta + mi;
                System.out.println("El monto final es: " + montofinal);
            }
            if(venta < 50 && venta > 0){
                impuesto = 0;
                mi = impuesto * venta;
                System.out.println("El impuesto es: " + mi);
                montofinal = venta + mi;
                System.out.println("El monto final es: " + montofinal);
            }
        }
    }
   
}
