/*
5.- (3 puntos). Escriba un programa que permita ingresar números, luego, permita
contar aquellos que sean múltiplo de 3 y finalice cuando se hayan ingresado 5 de 
estos múltiplos. Al final el programa debe mostrar cuantos números se han 
ingresado y cuantos números no son múltiplos de 3.
 */
package examen;

import java.util.Scanner;

/**
 *
 * @author o22226
 */
public class Pregunta5 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        int cont = 0;
        int total = 0;
        int no_multi = 0;
        
        while (cont<5)
        {
            System.out.println("Ingrese un número: ");
        
            double num = entrada.nextDouble();
            
            total = total + 1;
            
            if (num % 3 == 0) 
            {
                cont = cont + 1;
            }
            else
            {
                no_multi = no_multi + 1;
            }
        }
        
        System.out.println("El número total de número ingresados es " + total);
        System.out.println("El total de números no múltiplos de 3 ingresados es " + no_multi);
    }
}
