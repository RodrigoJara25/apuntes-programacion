/*
3.- (3 puntos) Escribir un programa donde se muestre un mensaje si un número es 
perfecto o no. La definición de un numero perfecto es la siguiente: la suma de 
sus divisores tiene que ser el número, por ejemplo 6 es un número perfecto ya 
que la suma de sus divisores 1+2+3 es igual a 6. El programa solicita números 
hasta que se ingresa un numero negativo.
 */
package examen;

import java.util.Scanner;

public class Ejercicio3 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingrese un número: ");
        int num = entrada.nextInt();
        
        while (num>=0)
        {
        int suma_divisores = 0;
        
        for (int i = 1; i < num; i++) 
        {
            if (num%i==0) 
            {
                suma_divisores = suma_divisores + i;
            }
        }
        
        if (suma_divisores==num) 
        {
            System.out.println("Es un número perfecto");
        }
        System.out.println("Ingrese un número: ");
        num = entrada.nextInt();
        }
    }
}
