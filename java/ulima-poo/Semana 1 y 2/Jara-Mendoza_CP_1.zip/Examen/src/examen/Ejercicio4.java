/*
4.- (2 puntos) Diseña un programa donde se ingrese temperaturas registradas 
durante una semana (en °C). Finalmente, el programa debe mostrar la temperatura 
más alta, la más baja y la temperatura promedio de la semana.
 */
package examen;

import java.util.Scanner;

public class Ejercicio4 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingrese la temperatura");
        
        double temp = entrada.nextDouble();
        
        double max = temp;
        double min = temp;
        double suma = temp;
        
        int i = 1;
        
        while (i<7)
        {   
            
            System.out.println("Ingrese la temperatura");
        
            temp = entrada.nextDouble();
            
            suma = suma + temp;
            
            if (temp > max) 
            {
                max = temp;
            }
            if (temp < min) 
            {
                min = temp;
            }
            
            i = i + 1;
        }
        
        double promedio = suma / 7;
        
        System.out.println("La máxima temperatura es " + max);
        System.out.println("La mínima temperatura es " + min);
        System.out.println("El promedio de las temperaturas es " + promedio);
    }
}
