package examen;
import java.util.Scanner;

public class Ejercicio2 {
    public static int ndivisores(int numero){
        int cant = 0;
        for (int i = 1; i < numero; i++) {
            if(numero % i == 0){
                cant = cant + 1;
            }
        }
        return cant;
    }
   
    public static int sdivisores(int numero){
        int suma = 0;
        for (int i = 1; i < numero; i++) {
            if(numero % i == 0){
                suma = suma + i;
            }
        }
        return suma;
    }
   
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = 0;
        for (int i = 1; i > 0; i++) {
            System.out.println("Ingrese un número: ");
            n = sc.nextInt();
            if(n == 0){
                break;
            }
            System.out.println("El número " + n + " contiene " +ndivisores(n) + " divisores y la suma de ellos es " + sdivisores(n));
        }
    }
}
