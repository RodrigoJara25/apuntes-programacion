/*
4. Escriba un programa en Java que solicite un valor entero al usuario. Si el valor 
está entre 1 y 100, imprima “OK” de lo contrario, escriba "Fuera de rango".
 */
package paquete;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejercicio4 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingrese un valor entero: ");
        
        int valor = entrada.nextInt();
        
        if (valor <= 100 && valor >=0) 
        {
            System.out.println("OK");            
        }
        else
        {
            System.out.println("Fuera de rango");
        }
        
    }
}
