/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejercicio6 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingrese un valor entero: ");
        int a = entrada.nextInt();
        
        System.out.println("Ingrese un valor entero: ");
        int b = entrada.nextInt();
        
        System.out.println("Ingrese un valor entero: ");       
        int c = entrada.nextInt();
        
        System.out.println("Ingrese un valor entero: ");    
        int d = entrada.nextInt();
        
        System.out.println("Ingrese un valor entero: ");       
        int e = entrada.nextInt();
        
        if (a!=b && a!=c && a!= d && a!=e && b!=a &&b!=c && b!=d && b!=e && c!=a && c!=b && c!=d && c!=e && d!=a && d!=b && d!=c && d!=e)
        {
            System.out.println("TODO ÚNICO");
        }
        else
        {
            System.out.println("DUPLICADO");
        }
    }
}
