/*
5. Escriba un programa en Java que solicite al usuario cinco valores enteros. Luego 
imprime los valores máximo y mínimo ingresados. Si el usuario ingresa los valores 3, 2, 5, 0 y 1, 
el programa indicaría que 5 es el máximo y 0 el mínimo. Su programa debe manejar los lazos 
correctamente; por ejemplo, si el usuario ingresa 2, 4, 2, 3 y 3, el programa debe informar 2 
como mínimo y 4 como máximo.
 */
package paquete;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejercicio5 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner (System.in);
        
        System.out.println("Ingrese cinco valores enteros: ");
        
        int valor1 = entrada.nextInt();
        
        int maximo = valor1;
        int minimo = valor1;
             
        
        for (int i = 0; i < 4; i++) 
        {
            int valor = entrada.nextInt();
            
            if (valor >= maximo) 
            {
                maximo = valor;
            }
            if (valor <= minimo) 
            {
                minimo = valor;
            }
        }
        
        System.out.println("El máximo valor es: " + maximo);
        System.out.println("El mínimo valor es: " + minimo);
    }
}
