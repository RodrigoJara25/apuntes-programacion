/*
2. Escribir un programa en la que el usuario ingrese un subtotal y la tasa de gratuidad. 
Calcule la gratuidad, el total y lo muestre. Por ejemplo, si el usuario ingresa $10 como 
subtotal y 15% para la tasa de gratuidad, el programa debe mostrar $1.5 como gratuidad y 
$11.5 como total.
 */
package paquete;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejercicio2 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingresar el subtotal: ");
        
        float subtotal = entrada.nextFloat();
        
        System.out.println("Ingrese la tasa de gratuidad: (en %)");
        
        float tasa_gratuidad = entrada.nextFloat() / 100 ;
        
        float gratuidad = tasa_gratuidad * subtotal;
        
        System.out.println("La gratuidad es: $" + gratuidad);
        
        float total = gratuidad + subtotal;
        
        System.out.println("El total es: $" + total);
        
        
        
        
    }
    
}
