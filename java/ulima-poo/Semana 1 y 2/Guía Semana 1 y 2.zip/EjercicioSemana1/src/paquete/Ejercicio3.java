/*
3. De la geometría: Escriba un programa de computadora que, dadas las longitudes 
de los dos lados de un triángulo rectángulo adyacente al ángulo recto, calcule la 
longitud de la hipotenusa del triángulo. 
 */
package paquete;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejercicio3 
{
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingrese la longitud de un cateto: ");
        
        double cateto1 = entrada.nextFloat();
        
        System.out.println("Ingrese la longitud del otro cateto: ");
        
        double cateto2 = entrada.nextFloat();
        
        double hipotenusa = Math.sqrt( Math.pow(cateto1, 2) + Math.pow(cateto2, 2) );
        
        System.out.println("La hipotenusa es: " + hipotenusa);
        
        System.out.println("El valor de la hipotenusa es: " + hipotenusa);
        
    }
}
