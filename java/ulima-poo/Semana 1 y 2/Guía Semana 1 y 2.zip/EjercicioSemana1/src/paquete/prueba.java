/*
1. Escribir un programa que lea por teclado un numero en pies y lo convierta en 
metros y muestre el resultado. Un pie es 0.305 metros.
 */
package paquete;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class prueba 
{
    public static void main(String[] args) 
    {        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingresar la longitud en pies: ");
        
        float pies = entrada.nextFloat();
        
        double metros = pies * 0.305;
        
        System.out.println("La longitud en metros es: " + metros);
        
    }
}
