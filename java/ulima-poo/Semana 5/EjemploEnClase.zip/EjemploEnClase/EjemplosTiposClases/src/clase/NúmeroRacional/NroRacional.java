/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase.NúmeroRacional;

/**
 *
 * @author Usuario
 */
public class NroRacional 
{
    //Atributos
    private int numerador;
    private int denominador;
    
    //Método Constructor
    public NroRacional(int numerador, int denominador) {
        this.numerador = numerador;
        this.denominador = denominador;
    }

    public NroRacional() {
        this.numerador = 0;
        this.denominador = 0;
    }
    
    //Métodos sobrecargadores
    
    
    
    
}
