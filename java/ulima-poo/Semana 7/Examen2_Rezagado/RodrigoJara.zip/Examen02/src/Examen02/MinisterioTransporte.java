/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Examen02;

import java.util.Random;

/**
 *
 * @author Usuario
 */
public class MinisterioTransporte 
{
    //Atributos
    private int[][] matriz;
    
    private int[] sumaXCalle;
    private int callesXAsfaltar;
    
    private int[] sumaXManzana;
    private int manzanasXCamaras;
    
    private int camarasx2;
    
    private Personal ref;
    
    private int maxCalle;
    private int maxManzana;
    
    private int calles;
    private int manzanas;
    
    //Constructor

    public MinisterioTransporte(Personal ref) 
    {
        this.calles = 15;
        this.manzanas = 20;
        
        this.matriz = new int[15][20];
        
        this.sumaXCalle = new int[15];
        this.callesXAsfaltar = 0;
        
        this.sumaXManzana = new int[20];
        this.ref = ref;
    }
    
    
    
    //Método
    Random rand = new Random();
    public void LlenarMatriz()
    {
        for (int i = 0; i < this.calles; i++) 
        {
            for (int j = 0; j < this.manzanas; j++) 
            {
                this.matriz[i][j]= rand.nextInt(21)+50;
            }   
        }
    }
    
    public void CallesAsfaltar()
    {
        int suma=0;
        for (int i = 0; i < this.calles; i++) 
        {
            for (int j = 0; j < this.manzanas; j++) 
            {
                suma = suma + this.matriz[i][j];
            }
            this.sumaXCalle[i]=suma;
            suma=0;
        }
        
        int asfaltar=0;
        for (int i = 0; i < this.calles; i++) 
        {
            if (this.sumaXCalle[i]>=1000) 
            {
                asfaltar = asfaltar + 1;
            }
        }
        this.callesXAsfaltar = asfaltar;
    }
    
    public void CamarasInstalar()
    {
        int suma =0;
        for (int j = 0; j < this.manzanas; j++) 
        {
            for (int i = 0; i < this.calles; i++) 
            {
                suma = suma + this.matriz[i][j];
            }
            this.sumaXManzana[j]=suma;
            suma=0;
        }
        int camaras=0;
        for (int i = 0; i < this.manzanas; i++) 
        {
            if (this.sumaXManzana[i]>=750 && this.sumaXManzana[i]<=850) 
            {
                camaras = camaras + 1;
            }
            else if (this.sumaXManzana[i]>=851 && this.sumaXManzana[i]<=1000) 
            {
                camaras = camaras + 2;
            }
            else
            {
                camaras = camaras + 3;
            }
        }
        this.manzanasXCamaras=camaras;
    }
    
    public void CamarasDobles()
    {
        int cant=0;
        for (int i = 0; i < this.manzanas; i++) 
        {
            if (this.sumaXManzana[i]>=851 && this.sumaXManzana[i]<=1000) 
            {
                cant = cant + 1;
            }
            this.camarasx2 = cant;
        }   
    }
    
    public void MaxCalleManzana()
    {
        int max =0;
        for (int i = 0; i < this.calles; i++) 
        {
            if (this.sumaXCalle[i]>max)
            {
                max = this.sumaXCalle[i];
            }
        }
        this.maxCalle = max;
        
        int max0=0;
        for (int i = 0; i < this.manzanas; i++) 
        {
            if (this.sumaXManzana[i]>max0) 
            {
                max0 = this.sumaXManzana[i];
            }
        }
        this.maxManzana = max0;
    }
    
    public String MostrarInfo()
    {
        String cad = "\t";
        
        for (int i = 0; i < this.manzanas; i++) 
        {
            cad = cad + "M" + (i+1) + "\t";
        }
        cad = cad + "\n";
        
        for (int i = 0; i < this.calles; i++) 
        {
            cad = cad + "C" + (i+1) + "\t";
            for (int j = 0; j < this.manzanas; j++) 
            {
                cad = cad + this.matriz[i][j] + "\t";
            }
            cad = cad + "\n";
        }
        
        cad = cad + "Cantidad de calles por asfaltar: " + this.callesXAsfaltar + "\n";
        cad = cad + "Cantidad de cámaras que se van a instalar: " + this.manzanasXCamaras + "\n";
        cad = cad + "Cantidad de manzanas con 2 cámaras por instalarse: " + this.camarasx2 + "\n";
        cad = cad + "Máximo de vehículos en una calle: " + this.maxCalle +
                "\nMáximo de vehículos en una manzana: " + this.maxManzana + "\n";
        
        cad = cad + ref.VerInfo();
        
        return cad;
    }
}
