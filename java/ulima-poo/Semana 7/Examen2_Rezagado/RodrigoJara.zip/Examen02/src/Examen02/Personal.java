/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Examen02;

/**
 *
 * @author Usuario
 */
public class Personal 
{
    //Atributos
    private String code;
    private String nombre;
    private int edad;
    private String sexo;
    
    //Métodos
    public Personal(String code, String nombre, int edad, String sexo) 
    {
        this.code = code;
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = sexo;
    }
    
    //Método
    public String VerInfo()
    {
        return "DATOS DEL PERSONAL: \n" +
                "Codigo: " + this.code + 
                "\nNombre: " + this.nombre +
                "\nEdad: " + this.edad + 
                "\nSexo: " + this.sexo;
    }
}
