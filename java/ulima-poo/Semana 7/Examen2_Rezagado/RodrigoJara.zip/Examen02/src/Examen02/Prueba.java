/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Examen02;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Prueba 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Ingrese el código del personal: ");
        String code = sc.nextLine();
        
        System.out.println("Ingrese el nombre del personal: ");
        String nombre = sc.nextLine();
        
        System.out.println("Ingrese la edad del personal: ");
        int edad = sc.nextInt();
        sc.nextLine();
        
        System.out.println("Ingrese el sexo del personal: ");
        String sexo = sc.nextLine();
        
        Personal personal1 = new Personal(code, nombre, edad, sexo);
        
        /*int calles;
        do 
        {
           System.out.println("Ingrese la cantidad de calles del distrito:"); 
           calles = sc.nextInt();
        } while (calles<0 || calles>15);
        
        int manzanas;
        do 
        {
           System.out.println("Ingrese la cantidad de manzanas del distrito:"); 
           manzanas = sc.nextInt();
        } while (manzanas<0 || manzanas>20);
        */
        MinisterioTransporte distrito1 = new MinisterioTransporte(personal1);
        
        distrito1.LlenarMatriz();
        distrito1.CallesAsfaltar();
        distrito1.CamarasInstalar();
        distrito1.CamarasDobles();
        distrito1.MaxCalleManzana();
        
        System.out.println(distrito1.MostrarInfo());
    }
    
}
