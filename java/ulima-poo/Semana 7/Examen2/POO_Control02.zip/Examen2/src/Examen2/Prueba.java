/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Examen2;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Prueba 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Ingrese el código: ");
        String code = sc.nextLine();
        
        System.out.println("Ingrese la ciudad: ");
        String ciudad = sc.nextLine();
        
        System.out.println("Ingrese el número de empleados: ");
        int empleados = sc.nextInt();
        
                
        MiNoticia obj1 = new MiNoticia(code, empleados, ciudad);
        
        obj1.DatosAdministrador();
        
        obj1.NumTipoLibros();
        
        obj1.LlenarMatriz();
        
        obj1.MayorPuntoVenta();
        
        System.out.println(obj1.MostrarInfo());
    }
    
}
