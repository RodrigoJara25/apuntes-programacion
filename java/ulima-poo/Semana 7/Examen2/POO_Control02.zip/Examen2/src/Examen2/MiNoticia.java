/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Examen2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class MiNoticia 
{
    //Atributos
    private int num_libros;
    private int[][] matriz;
    
    private String nombre;
    private String apellido;
    private int edad;
    
    private String code;
    private int empleados;
    private String ciudad;
    
    private int[] totalxPV;
    private String mayor_cantidad;
    
    
    //Método Constructor
    public MiNoticia(String code, int empleados, String ciudad) 
    {
        this.code = code;
        this.empleados = empleados;
        this.ciudad = ciudad;
        
        this.num_libros = 0;
        this.matriz = new int[8][25]; //se pone el máximo
        
        this.nombre = "";
        this.apellido = "";
        this.edad = 0;
        
        this.totalxPV = new int[25];
        this.mayor_cantidad = "";
    }
    
    
    //Métodos
    Scanner sc = new Scanner(System.in);
    
    public void NumTipoLibros()
    {
        int num;
        do 
        {
            System.out.println("Ingrese el número de tipo de libros: ");
            num = sc.nextInt();
        } while (num<0 || num>8);
        this.num_libros = num;
    }
    
    public void DatosAdministrador()
    {
        System.out.println("Ingrese el nombre del administrador: ");
        this.nombre = sc.nextLine();
        
        System.out.println("Ingrese el apellido del administrador: ");
        this.apellido = sc.nextLine();
        
        System.out.println("Ingrese la edad del administrador: ");
        this.edad = sc.nextInt();
    }
    
    Random rand = new Random();
    public void LlenarMatriz()
    {
        int num = 0;
        for (int i = 0; i < this.num_libros; i++) 
        {
            for (int j = 0; j < 25; j++) 
            {
                do 
                {
                    num = rand.nextInt(61)+25;
                } while (EsPrimo(num)==false);
                this.matriz[i][j] = num;
            }
        }
    }
    
    public void MayorPuntoVenta()
    {
        int suma = 0;
        for (int j = 0; j < 25; j++) 
        {
            for (int i = 0; i < this.num_libros; i++) 
            {
                suma = suma + this.matriz[i][j];
            }
            this.totalxPV[j] = suma;
            suma = 0;
        }
        
        int mayor = 0;
        for (int i = 0; i < 25; i++) 
        {
            if (this.totalxPV[i]>mayor) 
            {
                mayor = this.totalxPV[i];
            }
        }
        
        String cad = "";
        for (int i = 0; i < 25; i++) 
        {
            if (this.totalxPV[i]==mayor) 
            {
                cad = cad + "El punto de venta con mayor cantidad de libros en la sucursal " + this.ciudad
                            + " es " + "PV" + (i+1) + "\n";
            }
        }
        this.mayor_cantidad = cad;
    }
    
    public String MostrarInfo()
    {
        String cad = "\t";
        
        for (int i = 0; i < 25; i++) 
        {
            cad = cad + "PV" + (i+1) + "\t";
        }
        cad = cad + "\n";
        
        for (int i = 0; i < this.num_libros; i++) 
        {
            cad = cad + "L" + (i+1) + "\t";
            for (int j = 0; j < 25; j++) 
            {
                cad = cad + this.matriz[i][j] + "\t";
            }
            cad = cad + "\n";
        }
        
        cad = cad + "TOTAL" + "\t";
        for (int i = 0; i < 25; i++) 
        {
            cad = cad + this.totalxPV[i] + "\t";
        }
        cad = cad + "\n";
        
        cad = cad + "\n";
        
        cad = cad + this.mayor_cantidad + "\n";
        
        cad = cad + "\n" + "Datos del administrador: \n" + this.nombre + "\n" + 
                this.apellido + "\n" + this.edad;
        
        return cad;
    }
    
    //Función EsPrimo()
    public boolean EsPrimo(int num)
    {
        boolean primo=false;
        int cont=0;
        for (int i = 1; i <= num; i++) 
        {
            if (num%i==0) 
            {
                cont = cont + 1;
            }
        }
        if (cont==2) 
        {
            primo = true;
        }
        return primo;
    }
    
    
    
}
