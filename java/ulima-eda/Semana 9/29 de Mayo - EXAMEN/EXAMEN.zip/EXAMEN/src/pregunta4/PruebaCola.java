/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta4;

import java.util.Scanner;

/**
 *
 * @author l33221
 */
public class PruebaCola {
    
    public static int rango(Cola cola1, int inicio, int final1){
        Integer item;
        int contador = 0;
        for (int i = 0; i < 10; i++) {
                item = cola1.desencolar();
                if (item == null) {
                
            }
                else if (item>=inicio && item <= final1) {
                    contador++;
                }
            
        }
        return contador;
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese inicio: ");
        int inicio = sc.nextInt();
        System.out.println("Ingrese final: ");
        int final1 = sc.nextInt();
        
        //2, 3, 1, 4, 5, 10, 20 }
        
        Cola cola1 = new Cola();
        cola1.encolar(2);
        cola1.encolar(3);
        cola1.encolar(1);
        cola1.encolar(4);
        cola1.encolar(5);
        cola1.encolar(10);
        cola1.encolar(20);
        cola1.mostrarCola();
        
        int n;
        n = rango(cola1, inicio, final1);
        System.out.println("Respuesta: " + n);
    }
}
