/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta2;

/**
 *
 * @author l33221
 */
public class ListaEnlazada {
    private Nodo L;
    
    public ListaEnlazada() {
        this.L = null;
    }
    
    public boolean estaVacia() {
        if (this.L == null)
            return true;
        return false;
    }
    
    public void mostrar() {
        Nodo ptr = this.L;
        while(ptr != null) {
            System.out.print( ptr.getValue() + " -> ");
            ptr = ptr.getNext();
        }
        System.out.println("");
    }
    
    public void insertar(int item) {
        Nodo nuevo = new Nodo(item);
        
        if(estaVacia()) {
            this.L = nuevo;
        }
        else {
            Nodo ptr = this.L;
            while(ptr.getNext() != null) {
                ptr = ptr.getNext();
            }
            ptr.setNext(nuevo);
        }
    }
    
    public Integer buscar(int item) {
        Nodo ptr = this.L;
        while(ptr != null && ptr.getValue() != item) {
            ptr = ptr.getNext();
        }
        if(ptr == null) {
            return null;
        }
        else {
            return ptr.getValue();
        }
    }
    
    public void eliminar(int item) {
        Nodo ptr = this.L;
        Nodo prev = null;
        while(ptr != null && ptr.getValue() != item) {
            prev = ptr;
            ptr = ptr.getNext();
        }
        if (ptr != null && ptr.getValue() == item) {
            if (prev == null) {
                this.L = ptr.getNext();
            } else {
                prev.setNext(ptr.getNext());
            }
        }
    }
    
    
    
    public int cantElementos(){
        Nodo ptr = this.L;
        int cont = 0;
        while(ptr != null){
            cont++;
            ptr = ptr.getNext();
        }
        return cont;
    }
    
    public boolean esConsistente(){
        Nodo ptr = this.L;
        int cantidadTotal = cantElementos();
        if (L.getValue() == cantidadTotal) {
            System.out.println("Es consistente");
            return true;
        }
        else{
            System.out.println("No es consistente");
            return false;
        }
    }
}
