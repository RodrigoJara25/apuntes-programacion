/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta1;

/**
 *
 * @author l33221
 */
public class ListaEnlazada {
    private Nodo L;
    
    public ListaEnlazada() {
        this.L = null;
    }
    
    public boolean estaVacia() {
        if (this.L == null)
            return true;
        return false;
    }
    
    public void mostrar() {
        Nodo ptr = this.L;
        while(ptr != null) {
            System.out.print( ptr.getValue() + " -> ");
            ptr = ptr.getNext();
        }
        System.out.println("");
    }
    
    public void insertar(int item) {
        Nodo nuevo = new Nodo(item);
        
        if(estaVacia()) {
            this.L = nuevo;
        }
        else {
            Nodo ptr = this.L;
            while(ptr.getNext() != null) {
                ptr = ptr.getNext();
            }
            ptr.setNext(nuevo);
        }
    }
    
    public Integer buscar(int item) {
        Nodo ptr = this.L;
        while(ptr != null && ptr.getValue() != item) {
            ptr = ptr.getNext();
        }
        if(ptr == null) {
            return null;
        }
        else {
            return ptr.getValue();
        }
    }
    
    public void eliminar(int item) {
        Nodo ptr = this.L;
        Nodo prev = null;
        while(ptr != null && ptr.getValue() != item) {
            prev = ptr;
            ptr = ptr.getNext();
        }
        if (ptr != null && ptr.getValue() == item) {
            if (prev == null) {
                this.L = ptr.getNext();
            } else {
                prev.setNext(ptr.getNext());
            }
        }
    }
    
    public boolean tieneRepetidos(int valor){
        Nodo ptr = this.L;
        int cont = 0;
        while(ptr != null){
            if (ptr.getValue()==valor) {
                cont++;
            }
            ptr = ptr.getNext();
        }
        if (cont >= 2) {
            System.out.println("Si hay repetidos");
            return true;
        }
        else{
            System.out.println("No hay repetidos");
            return false;
        }
    }
}
