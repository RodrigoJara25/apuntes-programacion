/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta1;

/**
 *
 * @author l33221
 */
public class Nodo {
    private int value;
    private Nodo next;
    
    public Nodo(int value) {
        this.value = value;
        this.next = null;
    }
    
    public int getValue() {
        return value;
    }
    
    public Nodo getNext() {
        return next;
    }
    
    public void setNext(Nodo next) {
        this.next = next;
    }
}
