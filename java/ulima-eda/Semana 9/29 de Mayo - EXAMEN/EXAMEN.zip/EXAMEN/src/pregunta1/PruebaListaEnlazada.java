/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta1;

/**
 *
 * @author l33221
 */
public class PruebaListaEnlazada {
    public static void main(String[] args) {
        ListaEnlazada lista1 = new ListaEnlazada();
        lista1.insertar(5);
        lista1.insertar(1);
        lista1.insertar(6);
        lista1.insertar(8);
        lista1.insertar(10);
        lista1.insertar(4);
        lista1.mostrar();
        lista1.tieneRepetidos(6);
        lista1.insertar(6);
        lista1.mostrar();
        lista1.tieneRepetidos(6);
    }
    
}
