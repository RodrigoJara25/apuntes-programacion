/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta3;

import java.util.Objects;
import java.util.Scanner;

/**
 *
 * @author l33221
 */
public class PruebaPila {
    
    public static boolean esPalindromo(Pila p1, Pila pila_aux, int N){
        int dato;
        Pila p2 = p1;
        for (int i = 0; i < N; i++) {
            dato = p2.pop();
            pila_aux.push(dato); 
        }
        int cont=0;
        for (int i = 0; i < N; i++) {
            if (Objects.equals(pila_aux.pop(), p1.pop())) {
                cont++;
            }
        }
        return cont == N;
    }
    
    public static void main(String[] args) {
        
        //Scanner sc = new Scanner(System.in);
        //System.out.println("Ingrese el tamañano N de la pila: ");
        //int N = sc.nextInt();
        
        
        Pila p1 = new Pila();
        Pila p2 = new Pila();
        Pila pila_aux = new Pila();
        
        //0, 1, 0, 1, 1, 1, 0, 1, 0
        p1.push(0);
        p1.push(1);
        p1.push(0);
        p1.push(1);
        p1.push(1);
        p1.push(1);
        p1.push(0);
        p1.push(1);
        p1.push(0);
        p1.mostrarPila();
        
        //acá se debe actualizar el tamaño de la pila
        int tamaño = 9;
        int[] array = new int[tamaño];
        for (int i = 0; i < tamaño; i++) {
            array[i] = p1.pop();
        }
        for (int i = 0; i < tamaño; i++) {
            p1.push(array[i]); 
        }
        int cont=0;
        for (int i = 0; i < tamaño; i++) {
            p2.push(array[i]);
        }
        for (int i = 0; i < tamaño; i++) {
            if (p1.pop()==p2.pop()) {
                cont++;
            }
        }
        if (cont==tamaño) {
            System.out.println("true");
        }
        else{
            System.out.println("false");
        }
        
        
        //int n = p1.pop();
        //System.out.println("Número sacado: " + n);
        //if (esPalindromo(p1,pila_aux,N)==true) {
          //  System.out.println("true");
        //}
        //else{
          //  System.out.println("false");
        //}
    }    
}
