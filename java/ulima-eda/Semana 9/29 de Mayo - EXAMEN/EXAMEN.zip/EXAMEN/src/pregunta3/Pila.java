/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta3;

/**
 *
 * @author l33221
 */
public class Pila {
    private int MAX_SIZE=9;
    private int top;
    private int[] datos;
    
    public Pila() {
        datos = new int[MAX_SIZE];
        top = -1;
    }
    
    public boolean estaVacia() {
        if (top == -1)
            return true;
        return false;
    }
    
    public boolean estaLlena() {
        if (top == MAX_SIZE - 1)
            return true;
        return false;
    }
    
    public void push(int item) {
        if(!estaLlena()) {
            top++;
            datos[top] = item;
        }
    }
    
    public Integer pop() {
        if (!estaVacia()) {
            int elem = datos[top];
            top--;
            return elem;
        }
        return null;
    }

    public int[] getDatos() {
        return datos;
    }
    
    
    
    public void mostrarPila() {
        for (int i=0; i<MAX_SIZE; i++) {
            System.out.print(datos[i] + " | ");
        }
        System.out.println("Top: " + top);
    }   
}
