/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio_2;

/**
[5pts] Pregunta 2
Sea la clase TDAGrafo que representa un grafo de “n” vértices a través de una 
matriz de adyacencia.
Implemente el método verticesGradoPar dentro de la clase que muestre solo aquellos 
vértices que tengan
grado par. Puede implementar métodos auxiliares para calcular lo solicitado.
 */
public class Ejercicio_2 {
    public static void main(String[] args) {
        TDAGrafo g1 = new TDAGrafo(3);
        
        g1.insertarArista(0, 1);
        g1.insertarArista(0, 2);
        g1.insertarArista(2, 1);
        g1.insertarArista(2, 0);
        g1.insertarArista(1, 2);
        g1.insertarArista(1, 0);
        
        g1.mostrarGrafo();
        System.out.println("");
        
        g1.VerticeGradoPar();
        
    }
}
