/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio_1;

/**
[5pts] Pregunta 1
Sea A un arreglo unidimensional de N números enteros. Implemente una función 
* recursiva que determine
el número mayor en A.
 */

public class Ejercicio_1 {
    public static int Mayor(int[] A, int index){ 
        if (index == A.length-1) { 
            return A[index];
        }
        int maxResto = Mayor(A, index+1);
        
        if(A[index] >= maxResto){
            return A[index];
        }
        else{
            return maxResto;
        }
    }
    
    public static void main(String[] args) {
        int[] A = {1, 10, 3, 9, 12, 8};
        int mayor = Mayor(A, 0);
        System.out.println("El mayor elemento del arreglo es: " + mayor);
        //System.out.println("");
    }
    
}
