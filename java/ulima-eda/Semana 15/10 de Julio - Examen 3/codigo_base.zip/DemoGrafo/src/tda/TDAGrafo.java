package tda;

public class TDAGrafo {
    private int[][] matAdj;
    
    public TDAGrafo(int numVert) {
        matAdj = new int[numVert][numVert];
    }
    
    public void insertarArista(int vIni, int vFin) {
        matAdj[vIni][vFin] = 1;
    }
    
    public int[] adyacentes(int vertice) {
        int numAdj = 0;
        for (int i = 0; i < matAdj.length; i++) {
            if (matAdj[vertice][i] == 1)
                numAdj++;
        }
        int[] listAdj = new int[numAdj];
        int idx = 0;
        for (int i = 0; i < matAdj.length; i++) {
            if (matAdj[vertice][i] == 1) {
                listAdj[idx] = i;
                idx++;
            }
        }
        return listAdj;
    }
    
    public void bfs(int nodoInicial) {
        boolean[] visitados = new boolean[matAdj.length];
        TDACola cola = new TDACola();
        visitados[nodoInicial] = true;
        cola.encolar(nodoInicial);
        
        while(!cola.estaVacia()) {
            int nodo = cola.desencolar();
            System.out.println("Nodo visitado: " + nodo);
            int [] adj = adyacentes(nodo);
            for (int i = 0; i < adj.length; i++) {
                if (visitados[adj[i]] == false) {
                    visitados[adj[i]] = true;
                    cola.encolar(adj[i]);
                }
            }
            cola.mostrarCola();
        }
    }
    
    public void dfs(int nodoInicial) {
        boolean[] visitados = new boolean[matAdj.length];
        TDAPila cola = new TDAPila();
        visitados[nodoInicial] = true;
        cola.push(nodoInicial);
        
        while(!cola.estaVacia()) {
            int nodo = cola.pop();
            System.out.println("Nodo visitado: " + nodo);
            int [] adj = adyacentes(nodo);
            for (int i = 0; i < adj.length; i++) {
                if (visitados[adj[i]] == false) {
                    visitados[adj[i]] = true;
                    cola.push(adj[i]);
                }
            }
        }
    }
    
    public void mostrarGrafo() {
        for (int i = 0; i < matAdj.length; i++) {
            for (int j = 0; j < matAdj.length; j++) {
                System.out.print(matAdj[i][j] + " ");
            }
            System.out.println("");
        }
    }
}
