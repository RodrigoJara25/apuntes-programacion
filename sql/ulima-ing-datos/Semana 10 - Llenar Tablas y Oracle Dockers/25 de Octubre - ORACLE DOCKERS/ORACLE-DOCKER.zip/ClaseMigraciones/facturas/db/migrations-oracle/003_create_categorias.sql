-- up
CREATE TABLE categorias(
	id NUMBER(7) PRIMARY KEY,
	name VARCHAR2(20),
    codigo NUMBER(5)
);

ALTER TABLE categorias ADD (
  CONSTRAINT categorias_pk PRIMARY KEY (ID));

CREATE SEQUENCE categorias_seq START WITH 1;

CREATE OR REPLACE TRIGGER categorias_pk 
BEFORE INSERT ON categorias 
FOR EACH ROW

BEGIN
  SELECT categorias_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

-- down

DROP SEQUENCE categorias_seq;
DROP TABLE categorias;