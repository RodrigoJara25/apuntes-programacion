-- up
CREATE TABLE media_types(
	id NUMBER(7) PRIMARY KEY,
	name VARCHAR2(120)
);

ALTER TABLE media_types ADD (
  CONSTRAINT media_types_pk PRIMARY KEY (ID));

CREATE SEQUENCE media_types_seq START WITH 1;

CREATE OR REPLACE TRIGGER media_types_pk 
BEFORE INSERT ON media_types 
FOR EACH ROW

BEGIN
  SELECT media_types_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

-- down

DROP SEQUENCE media_types_seq;
DROP TABLE media_types;