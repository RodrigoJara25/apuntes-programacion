-- migrate:up

INSERT INTO categorias (id, nombre, codigo) VALUES (1,'Electrónica',3209);
INSERT INTO categorias (id, nombre, codigo) VALUES (2,'Ropa y Accesorios',2025);
INSERT INTO categorias (id, nombre, codigo) VALUES (3,'Alimentos y Bebidas',3776);
INSERT INTO categorias (id, nombre, codigo) VALUES (4,'Hogar y Jardín',1747);
INSERT INTO categorias (id, nombre, codigo) VALUES (5,'Salud y Belleza',3046);
INSERT INTO categorias (id, nombre, codigo) VALUES (6,'Juguetes y Juegos',2094);
INSERT INTO categorias (id, nombre, codigo) VALUES (7,'Deportes y Aire Libre',1453);
INSERT INTO categorias (id, nombre, codigo) VALUES (8,'Automotriz',4949);
INSERT INTO categorias (id, nombre, codigo) VALUES (9,'Libros y Medios',4467);
INSERT INTO categorias (id, nombre, codigo) VALUES (10,'Tecnología de la Información',4171);

-- migrate:down

DELETE FROM categorias