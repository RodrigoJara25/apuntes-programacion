INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (1, 'William Moran', '921 Duncan Ports
South Johnmouth, ND 69666', 87950976, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (2, 'Jason Murillo', '125 Buchanan Freeway
Parsonsburgh, RI 37375', 61509664, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (3, 'Robert Miller', 'USS Andrews
FPO AA 91454', 10545700, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (4, 'Laura Tucker', '16534 Ramos Isle
South Ericfurt, LA 27199', 98913606, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (5, 'Jennifer Chang', '2937 Price Fall Apt. 191
Port Steven, PA 45474', 19792233, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (6, 'Michael Sawyer', '37355 Acosta Ville
Melissaton, MP 04712', 44320634, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (7, 'Rodney Robinson', 'Unit 3080 Box 4172
DPO AE 79772', 63789241, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (8, 'Rachael Stevens', '0230 Smith Ferry
Christopherfurt, IN 37808', 16444882, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (9, 'James Wiley', '6909 Roman Cliff Suite 443
Lake Katherine, CT 87248', 27385681, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (10, 'Gina Cooper', 'USNS Moore
FPO AE 35728', 68853896, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (11, 'Katherine Tucker', '56696 Lane Fort
Kevinton, NJ 42255', 44972262, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (12, 'Laura Kelly', 'Unit 1318 Box 4896
DPO AA 41928', 98928856, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (13, 'Dennis Tran', '434 Cordova Groves Suite 574
Lake Brian, WV 83720', 72898992, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (14, 'Alyssa Spence', '9198 Bonnie Ramp
Johnport, GU 50057', 47482270, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (15, 'Billy Ross', '802 Pearson Inlet Suite 280
New Robert, IA 09772', 26538813, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (16, 'Richard Jones', 'USCGC Nelson
FPO AE 69209', 44002156, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (17, 'Kaitlin White', '79752 Lynn Mills
West Matthew, MT 38387', 15659208, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (18, 'Mr. Martin Potter', '6681 Jones Trace
Port Samantha, CT 89859', 22235325, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (19, 'Ricardo Nelson', '399 Alex Place Apt. 777
Williamberg, IL 44921', 39308531, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (20, 'Caitlyn Gross', '422 Bush Trail
New Staceymouth, DE 04137', 68069357, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (21, 'Zachary Jones', '589 Williams Centers
Phillipsville, IA 23057', 87054012, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (22, 'Anita Torres', '09477 Angela Brooks
New Patrickburgh, OH 99229', 30995291, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (23, 'Daniel Kim', '09507 Jeffrey Lodge
Meganfurt, AZ 62107', 85396647, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (24, 'Timothy Ruiz', '98690 Nicholas Parkways
Hubbardville, PR 11874', 20511752, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (25, 'Darryl Anderson', 'PSC 0375, Box 4172
APO AE 24823', 52047594, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (26, 'John Benton', '6061 Thomas Points
Lake Joanna, PA 08734', 30568204, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (27, 'Mr. Robert Moran', '672 Cheryl Cliffs
North Bethany, NY 56144', 98643310, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (28, 'Gregory Johnson', '60316 Mccullough Skyway Suite 231
South Jane, IN 58880', 66334146, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (29, 'James Kim', 'PSC 2539, Box 7693
APO AE 61180', 91608283, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (30, 'Tonya Henry', '38197 Bradley Trafficway Apt. 062
South Jose, PA 93407', 99016036, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (31, 'Diana Richardson', '730 Dodson Isle Suite 032
Smithhaven, TN 34396', 62903588, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (32, 'Susan Williams', '753 Michael Mountain Suite 884
South Jason, CA 02210', 23590417, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (33, 'Jorge Patterson', '347 Rodriguez Dam
Millershire, UT 09971', 24007780, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (34, 'Erin Jones', '95760 Blackburn Shores
South Betty, MO 47288', 79915735, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (35, 'Charlotte Salazar', '9783 Benton Avenue Apt. 380
Angelaborough, PW 95099', 73927273, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (36, 'Laurie Peters', '64617 Tracey Cliffs Apt. 425
Port Tommy, KS 44286', 82234886, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (37, 'Renee House', '04459 Carlson Camp Suite 299
Port Michael, MS 94916', 36766106, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (38, 'Ellen Daniels', '68713 Angela Estates
Fryemouth, PW 26014', 29407028, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (39, 'Bruce Lambert', '0488 April Village
North Maryside, ID 90642', 23670993, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (40, 'Kelly Pitts', '958 Stephanie Underpass
Westchester, MH 87509', 43346101, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (41, 'Autumn Schaefer', 'USNS Bush
FPO AP 79086', 34007537, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (42, 'Maureen Snyder', '094 Jennifer Mission
West Ryan, KS 84192', 95025001, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (43, 'Raymond Allen', '316 Gonzalez Lodge
Jonesview, OH 94571', 81367674, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (44, 'Justin Cline', '74658 Sherri Parkways Apt. 572
Buckleystad, FL 86686', 58523477, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (45, 'Nancy Banks', '05480 Emily Prairie Apt. 772
East Nicholashaven, TX 74575', 46680942, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (46, 'Danielle Campbell', '2112 Troy Centers Suite 209
Catherinechester, OK 28733', 56513957, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (47, 'Carla Huang', '44020 Johnson Ridge Suite 157
Lake Maryshire, MO 10142', 12703390, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (48, 'Robert Torres', '811 Matthew Islands Apt. 920
Port Kaitlyn, NE 86980', 21275600, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (49, 'Kevin Mosley', '8040 Nicholas Inlet
West Christopherbury, LA 38790', 12956692, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (50, 'Anna Winters', '815 Walker Summit
Shaneview, VI 46470', 10873613, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (51, 'Erin Oliver', '868 Kenneth Valley Apt. 157
Rhondaberg, PA 81025', 35063178, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (52, 'Jasmine Robles', 'USNS Miller
FPO AA 87217', 52502479, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (53, 'Joshua Jenkins', 'PSC 2651, Box 7538
APO AE 12733', 20399995, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (54, 'Mrs. Sarah Lyons', '29493 Nelson Pass
Scottville, NM 18387', 52893331, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (55, 'Renee Murray', 'PSC 8371, Box 0237
APO AA 84305', 64703724, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (56, 'Charles Ochoa', '931 Ashley Prairie
Taylorberg, SD 88462', 17607228, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (57, 'Jennifer Johnson', '770 Smith Fort
Katrinaton, PW 58123', 87002350, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (58, 'Kimberly Sheppard', '17859 Turner Locks
Port Marcus, MT 93036', 61218982, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (59, 'Mr. Daniel Perkins MD', '59497 Allen Greens
West David, MI 90661', 70544134, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (60, 'Robert Kent', '5316 Angela Plaza
East Brandonchester, PA 69694', 53567921, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (61, 'Jonathon Smith', '2764 Nathan Knoll
West Krystal, VI 48800', 61966597, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (62, 'Tom Becker', '04967 Nielsen Shore
North Kaitlyn, KY 24168', 82952773, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (63, 'Angelica Walters', '395 Amanda Center Suite 166
Lake Kevin, UT 12843', 37703119, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (64, 'Susan Huffman', '92536 Melissa Roads
South Rebeccaton, NC 09729', 91889255, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (65, 'Paula Nelson', '0940 James Summit Apt. 545
North Edward, VA 63197', 80989892, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (66, 'Lisa Johnston', '667 Raymond Alley Apt. 443
South Selena, NV 59083', 55528747, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (67, 'Blake Rivera', '448 Gonzalez Neck Suite 695
New Jamesbury, MH 96188', 89363505, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (68, 'Jordan Lopez', '7980 Guzman Harbors Suite 034
Chambersland, MD 29296', 53860614, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (69, 'Jonathan Martinez', '9605 Goodwin Fort Suite 057
Taylorfurt, NM 64849', 14527551, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (70, 'Julie Nunez', '5743 Reyes Camp
Janiceport, KS 92956', 93222767, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (71, 'Mr. Michael Cox', '3770 Koch Lakes Apt. 841
Jacksonberg, ME 82028', 36190644, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (72, 'Heather Ruiz', '24497 Woodard Roads
Robertsville, TX 02949', 95728588, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (73, 'April Jackson', '8282 Natasha Mount Apt. 050
New Kyle, MP 31342', 27032316, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (74, 'Ryan Williams', '15074 Carney Cliffs Suite 246
South Hannah, AS 10317', 38791193, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (75, 'Carolyn Murphy', '568 Alicia Springs Apt. 595
New Scott, AR 90142', 71366302, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (76, 'Melanie Barnes', '5048 Terrance Spring Apt. 987
North Danburgh, UT 78135', 94797413, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (77, 'Pamela Krueger', '9209 Russell Fork
East Gloriaton, NJ 33057', 23091210, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (78, 'Christopher Walsh', '1586 Bridget Squares
Andrewfurt, FL 14768', 55559213, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (79, 'Susan Foster', '4139 Hayes Spur
New Christine, MP 44070', 71107502, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (80, 'Katelyn Kennedy', '280 Lauren Squares
Port Gary, TN 95663', 19963928, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (81, 'Mr. Thomas Esparza', '59639 Crystal Shores Apt. 511
New Lauraburgh, UT 46808', 11676016, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (82, 'Casey Durham', '07060 Wilkins Pass Suite 603
Latoyastad, OR 47119', 89996253, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (83, 'Zachary Johnson', 'USNS Stevenson
FPO AE 58273', 10235172, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (84, 'Vernon Miller', '804 Gilbert Circle
West Tammyfurt, NV 09321', 87505132, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (85, 'Kayla Jones', '1244 Frank Court
Bellmouth, MO 05456', 20599834, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (86, 'Amy Price', '834 Sarah Forks Apt. 295
Lake Donna, WV 63553', 99120858, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (87, 'Jessica Mooney', '06878 Meagan Isle
Hawkinsstad, MT 79435', 67079503, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (88, 'Amanda Perez', '19741 Douglas Knolls Suite 863
Virginiaton, AZ 77237', 96810627, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (89, 'Melissa Huffman', '895 Kathryn Knoll Apt. 564
Whiteshire, ME 65062', 88889601, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (90, 'Dr. Lindsey Jimenez', '14226 Charles Ramp
East Elizabeth, MA 90093', 73419662, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (91, 'Christine Richardson', '42355 Christy Views
Rosston, AK 52885', 23924461, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (92, 'Kristen Lowe', '6100 Campbell Orchard
Jeffreyview, WA 17543', 21879601, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (93, 'Tammy Brown', 'Unit 8879 Box 2253
DPO AP 68063', 73408587, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (94, 'Tammy Kennedy', '25796 Perez Wall
Andersonmouth, FM 95860', 36613762, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (95, 'Amy Snyder', '32695 Ashley Keys Suite 119
Claudiaville, GA 85837', 93990385, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (96, 'Brian Davis', '24664 Harmon Ramp
Daniellefurt, UT 54548', 89788268, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (97, 'Megan Williams', '885 Christine Gardens Apt. 500
Lewisberg, HI 36610', 70978841, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (98, 'Justin Escobar', '362 Williams Keys
Wilsonside, SD 41040', 76561654, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (99, 'Robert Holt', '0009 Clark Mews Apt. 529
New Christopher, ND 16267', 94020027, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (100, 'Thomas Smith', '717 Chelsea Green Suite 968
Davidfort, NC 47089', 69087292, 3);
