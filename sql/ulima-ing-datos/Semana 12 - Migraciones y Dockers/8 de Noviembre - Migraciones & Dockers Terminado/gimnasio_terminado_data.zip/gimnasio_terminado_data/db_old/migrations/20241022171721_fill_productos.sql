-- migrate:up

INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (1, 'Teléfonos', 3381, 'Provide sport do amount thousand federal way. And blood century two.', 1.94, 1);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (2, 'Computadoras', 1027, 'Whatever control likely drop. Enough store happy oil possible.', 1.62, 1);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (3, 'Televisores', 1832, 'Woman expert two.', 0.84, 1);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (4, 'Audio', 3250, 'Five yourself sit much. Product so Mr single item eight.', 1.67, 1);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (5, 'Prendas de vestir', 3554, 'Focus fly political wish successful past factor.', 0.44, 2);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (6, 'Calzado', 2546, 'Else approach song learn compare. Difference camera enough.', 0.78, 2);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (7, 'Joyería', 1711, 'Concern alone where three already protect. Account store country structure buy spend something American. Position fine and risk could interesting.', 1.2, 2);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (8, 'Comidas enlatadas', 1875, 'Behind later report guy. Rich half form.', 0.12, 3);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (9, 'Snacks', 2255, 'When Republican cell during second determine prepare. Enough responsibility perform right article. Born yard region consumer tell.', 0.25, 3);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (10, 'Bebidas', 4625, 'Might score much much. Political up under already production sign. Agree travel garden wide common.', 0.07, 3);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (11, 'Muebles', 2107, 'Water it almost yourself term set. Usually how quite including drug woman job. Me young though oil least listen.', 1.73, 4);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (12, 'Decoración', 2496, 'North reason early enough piece dinner.', 0.54, 4);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (13, 'Herramientas de jardín', 2218, 'Talk serve half. Move usually democratic civil list. Consider size four later remember economic.', 0.85, 4);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (14, 'Cosméticos', 3944, 'Kitchen per leg see. Who education stock expert question goal.', 1.4, 5);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (15, 'Productos de cuidado personal', 4976, 'View fish remain think human group statement. Kid program like computer claim bad talk. Couple democratic best compare today perhaps service.', 0.54, 5);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (16, 'Suplementos', 4444, 'Everyone with American chance. Result either save suffer official. Spring girl police front why music certainly.', 0.88, 5);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (17, 'Juguetes educativos', 3013, 'Might both I name. She bar street.', 0.74, 6);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (18, 'Juegos de mesa', 2522, 'Worry down than center amount statement. None room quite pretty low social get.', 0.12, 6);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (19, 'Videojuegos', 2910, 'Feel foot next edge outside wear. Catch support child someone. Lead call Democrat.', 0.73, 6);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (20, 'Equipamiento deportivo', 3484, 'Now business together send. Food sell result evidence end mouth. Turn think pattern nothing whose response chair.', 1.45, 7);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (21, 'Ropa deportiva', 1691, 'Physical method get charge. Administration could east sometimes second term event. Often remember manager be hot discussion majority. Space including character process.', 1.17, 7);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (22, 'Accesorios de camping', 2424, 'Call career stay or. Interesting nature million. From resource food put huge local.', 1.81, 7);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (23, 'Accesorios para autos', 4807, 'Cell teacher science note medical huge stuff. Entire yourself attack friend give.', 1.74, 8);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (24, 'Herramientas', 3389, 'Official newspaper third imagine. Alone painting product foreign. Machine of top decision heart these impact card. Begin gun if family value field reality.', 0.49, 8);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (25, 'Productos de mantenimiento', 2322, 'Arm per art she. Now guy skill president let.', 0.36, 8);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (26, 'Libros', 4924, 'Seek star camera prepare available. Mind hundred shoulder. Month seem court bit commercial important difficult.', 1.57, 9);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (27, 'Revistas', 2704, 'Move bill resource top capital space. Today interesting notice beyond rule wrong police.', 0.73, 9);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (28, 'Música', 3755, 'Foreign city avoid light. Reveal success list security.', 0.93, 9);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (29, 'Películas', 2619, 'Little message population kid join. Specific now Mr meet media pay tell. Film style buy again.', 0.28, 9);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (30, 'Software', 2869, 'Any price before finally. Police between whatever success TV up treat. Report husband travel tree professional. Machine amount TV.', 1.2, 10);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (31, 'Aplicaciones', 1631, 'People fire far thousand which. Sit have create modern size shake. Upon author direction board into end speak.', 1.84, 10);
INSERT INTO productos (id, nombre, codigo, descripcion, valor_unitario, categoria_id) VALUES (32, 'Servicios en la nube', 3868, 'Knowledge policy product apply. Cut kitchen be officer. Clearly sell need drop ahead spring reach.', 1.55, 10);

-- migrate:down

DELETE FROM productos;