-- migrate:up
CREATE TABLE miembros (
  id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  nombre VARCHAR(30),
  apellidos  VARCHAR(30),
  codigo INTEGER
);

-- migrate:down
DROP TABLE miembros;

