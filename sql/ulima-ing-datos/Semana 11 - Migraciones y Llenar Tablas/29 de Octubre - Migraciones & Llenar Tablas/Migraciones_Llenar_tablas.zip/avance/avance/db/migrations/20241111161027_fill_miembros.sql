-- migrate:up
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (1, "Ana", "García", 2022122);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (2, "Carlos", "Rodríguez", 2022079);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (3, "Sofía", "López", 2022782);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (4, "Miguel", "Martínez", 2022681);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (5, "Valentina", "Hernández", 2022120);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (6, "José", "González", 2022319);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (7, "Mariana", "Pérez", 2022680);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (8, "Luis", "Sánchez", 2022872);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (9, "Isabella", "Ramírez", 2022590);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (10, "David", "Torres", 2022384);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (11, "Camila", "Álvarez", 2022239);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (12, "Pedro", "Díaz", 2022409);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (13, "Lucía", "Morales", 2022913);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (14, "Fernando", "Fernández", 2022047);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (15, "Gabriela", "Jiménez", 2022779);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (16, "Javier", "Ruiz", 2022327);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (17, "Elena", "Vázquez", 2022358);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (18, "Diego", "Molina", 2022494);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (19, "Victoria", "Cruz", 2022313);
INSERT INTO miembros (id, nombre, apellidos, codigo) VALUES (20, "Raúl", "Reyes", 2022854);

-- migrate:down
DELETE FROM miembros;
