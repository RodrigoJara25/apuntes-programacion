-- migrate:up
INSERT INTO niveles (nombre) VALUES ("Principiante");
INSERT INTO niveles (nombre) VALUES ("Intermedio");
INSERT INTO niveles (nombre) VALUES ("Avanzado");
INSERT INTO niveles (nombre) VALUES ("Experto");
INSERT INTO niveles (nombre) VALUES ("Nuevo");
INSERT INTO niveles (nombre) VALUES ("Novato");
INSERT INTO niveles (nombre) VALUES ("Aprendiz Básico");
INSERT INTO niveles (nombre) VALUES ("Aprendiz Intermedio");
INSERT INTO niveles (nombre) VALUES ("Aprendiz Avanzado");
INSERT INTO niveles (nombre) VALUES ("Atleta Principiante");
INSERT INTO niveles (nombre) VALUES ("Atleta Intermedio");
INSERT INTO niveles (nombre) VALUES ("Atleta Avanzado");
INSERT INTO niveles (nombre) VALUES ("Competidor Novato");
INSERT INTO niveles (nombre) VALUES ("Competidor Intermedio");
INSERT INTO niveles (nombre) VALUES ("Competidor Avanzado");
INSERT INTO niveles (nombre) VALUES ("Maestro en Entrenamiento");
INSERT INTO niveles (nombre) VALUES ("Maestro Avanzado");
INSERT INTO niveles (nombre) VALUES ("Elite");
INSERT INTO niveles (nombre) VALUES ("Pro");
INSERT INTO niveles (nombre) VALUES ("Master");

-- migrate:down
DELETE FROM niveles;
