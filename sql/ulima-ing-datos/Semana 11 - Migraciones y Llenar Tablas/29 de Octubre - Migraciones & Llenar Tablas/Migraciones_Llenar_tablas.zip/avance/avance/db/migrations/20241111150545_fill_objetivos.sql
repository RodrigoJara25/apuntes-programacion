-- migrate:up
INSERT INTO objetivos (id, nombre) VALUES (1, 'Aumentar masa muscular');
INSERT INTO objetivos (id, nombre) VALUES (2, 'Perder peso');
INSERT INTO objetivos (id, nombre) VALUES (3, 'Mejorar resistencia cardiovascular');
INSERT INTO objetivos (id, nombre) VALUES (4, 'Tonificar músculos');
INSERT INTO objetivos (id, nombre) VALUES (5, 'Aumentar fuerza');
INSERT INTO objetivos (id, nombre) VALUES (6, 'Mejorar flexibilidad');
INSERT INTO objetivos (id, nombre) VALUES (7, 'Reducir grasa corporal');
INSERT INTO objetivos (id, nombre) VALUES (8, 'Desarrollar core y estabilidad');
INSERT INTO objetivos (id, nombre) VALUES (9, 'Preparación para competencia');
INSERT INTO objetivos (id, nombre) VALUES (10, 'Mantener la salud general');

-- migrate:down
DELETE FROM objetivos;
