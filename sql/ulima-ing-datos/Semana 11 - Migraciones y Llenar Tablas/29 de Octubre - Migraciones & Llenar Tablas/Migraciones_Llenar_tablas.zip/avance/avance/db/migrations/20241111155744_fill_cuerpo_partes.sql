-- migrate:up
INSERT INTO cuerpo_partes (id, nombre) VALUES (1, "Pechos (Pectorales)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (2, "Espalda (Dorsales, Trapecios)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (3, "Brazos (Bíceps, Tríceps)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (4, "Hombros (Deltoides)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (5, "Abdomen (Recto abdominal, Oblicuos)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (6, "Piernas (Cuádriceps, Isquiotibiales, Glúteos)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (7, "Pantorrillas (Gastrocnemios, Sóleo)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (8, "Trapecios");
INSERT INTO cuerpo_partes (id, nombre) VALUES (9, "Lumbares (Espalda baja)");
INSERT INTO cuerpo_partes (id, nombre) VALUES (10, "Glúteos");
INSERT INTO cuerpo_partes (id, nombre) VALUES (11, "Antebrazos");
INSERT INTO cuerpo_partes (id, nombre) VALUES (12, "Caderas (Abductores, Aductores)");

-- migrate:down
DELETE FROM cuerpo_partes;
