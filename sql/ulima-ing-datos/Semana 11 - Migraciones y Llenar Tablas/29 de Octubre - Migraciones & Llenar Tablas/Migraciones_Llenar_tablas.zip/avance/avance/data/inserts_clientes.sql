INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (1, 'Sean Hernandez', '163 Michelle Lake
South David, AL 13156', 97869293, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (2, 'Jennifer Whitaker', '881 King Rapids Apt. 424
North Ianmouth, NE 41387', 78666894, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (3, 'Steven Ford', '8559 Willie Motorway Suite 461
Watersburgh, PR 46843', 24062522, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (4, 'Christopher Shepherd', '71333 Figueroa Prairie
South Tammy, PA 53629', 98292697, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (5, 'Nicholas Potter', '502 Mike Causeway Apt. 186
South Conniemouth, NJ 73503', 15867407, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (6, 'Thomas Nichols', 'USNV Carpenter
FPO AP 74432', 11803386, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (7, 'Robert Ross', '73907 Kenneth Square Suite 329
Lake Emilymouth, NM 64586', 71767599, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (8, 'Randy Anderson', '7217 Wells Crossing
East Kimberlyview, KS 43784', 41065540, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (9, 'Nathan Banks', '8985 Stacey Motorway Suite 389
North Garyside, AL 46684', 88273433, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (10, 'Timothy Harvey', '258 Stevens Forest Suite 512
Port Brittney, WI 98824', 62422340, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (11, 'Taylor Wallace', '68305 Douglas Drive
Mariaborough, NV 71583', 48473047, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (12, 'James Woodard', '9844 Stephanie Plaza
Nicolechester, VA 61482', 28301512, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (13, 'Dalton Griffith', '89341 Courtney Crescent Apt. 400
Matthewstad, AS 02687', 67289401, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (14, 'Yesenia Green', '92958 John Village
Campbellmouth, GA 59525', 22847776, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (15, 'Lindsay Burgess', '625 Morris Court Apt. 867
Troyborough, TN 88225', 57371326, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (16, 'Kathryn Baker', '285 Laura Manors
Erikfurt, KY 53741', 68340273, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (17, 'Kevin Brewer Jr.', '737 Foster Drives
Robertview, KS 30896', 11301021, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (18, 'Dorothy Young', '73654 Martin Spurs Suite 658
Stacyfort, NJ 50041', 72361187, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (19, 'Cindy Brady DDS', '9534 Johnson Gateway Apt. 781
Petersonshire, RI 08103', 52327455, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (20, 'Carlos Cole', '77395 Gutierrez Mall
Margaretport, NV 30489', 40096076, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (21, 'Jared Keith', 'PSC 7965, Box 9668
APO AP 46802', 27728515, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (22, 'Samuel Washington', '45748 Bradley Plaza Apt. 394
West Brian, NJ 59248', 29074571, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (23, 'Michelle Simpson', '973 Sierra Stravenue
Jimmyfurt, SC 54814', 67638613, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (24, 'Samantha Chandler', '374 Donald Crescent Suite 325
West Tyronebury, LA 06925', 30789528, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (25, 'Frank Duncan', '21045 Ford Shore Apt. 599
Port Melinda, GU 04804', 11722084, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (26, 'Lindsey Hayes', '9491 Montoya Via Suite 571
South Kelseyville, UT 48085', 54199039, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (27, 'Nancy Edwards', '618 James Village
South David, UT 78611', 33027154, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (28, 'Kristen Day', '31964 Park Lodge
South Justinmouth, MT 70170', 60340768, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (29, 'John Carlson', '82783 Lester Plaza Suite 513
Thomaschester, CA 65681', 70117788, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (30, 'Barbara Hall', '17353 Monica Islands Suite 166
Kimberlyport, MI 85719', 30916100, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (31, 'Ricky Gross', '7260 Jennifer Field Apt. 870
Mooneyhaven, ND 33615', 56003989, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (32, 'Kevin Gonzales', '2557 Wade Crescent
Port Yolanda, FM 87059', 85379075, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (33, 'Carrie Jordan', '718 Price Mountain Apt. 247
East Lisaview, LA 30541', 91335615, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (34, 'Kathryn Stewart', '12869 Eddie Villages Apt. 211
Roytown, OK 22821', 68691666, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (35, 'Richard Edwards MD', 'PSC 5246, Box 3388
APO AP 87532', 96195542, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (36, 'Sabrina Maldonado', '576 Rebecca Common Suite 304
Port Sierra, CT 12425', 50164963, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (37, 'Heather Watson', '500 Angela Pike
Weavermouth, WA 53238', 54222024, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (38, 'Taylor Miller', '997 Townsend Spur Apt. 141
Laurafort, NH 24001', 48153560, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (39, 'Andrea Greene', 'Unit 4446 Box 5639
DPO AP 71785', 84350162, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (40, 'Patricia Reynolds', '2188 Avila Corners
Bakerburgh, HI 92227', 53326847, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (41, 'Christina Ryan', '9296 Mcdowell Lodge Apt. 107
Lake Jessica, AR 71146', 21883906, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (42, 'Colton Strickland', '924 Jackson Villages
Carlsonville, MA 68700', 48313006, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (43, 'Becky Greene', '675 Walsh Orchard Apt. 257
Lake Jennifermouth, WV 14212', 26489374, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (44, 'Raven Ellis', '91716 Mack Drive Suite 822
Port Melindashire, SC 68231', 73664481, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (45, 'Rachel Gonzalez', '55402 Duarte Dam
Mcmillanchester, DC 85188', 95818850, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (46, 'Jacob Rice', '766 Jones Gardens Apt. 863
Gallaghermouth, CA 15527', 57719439, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (47, 'Robert Hudson', '896 Gould Tunnel
South Eric, VT 52752', 36404065, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (48, 'Mathew Shannon', '2088 Rivera Island
New Andrewside, SD 02419', 55797316, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (49, 'Steven Smith', '35436 Jesse Stream Suite 147
South Michael, TX 26755', 19272338, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (50, 'Timothy Nelson', '3306 Denise Row Apt. 853
East Anthony, AL 71964', 86171089, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (51, 'Kenneth Andrews', '824 Stephenson Vista
Ericchester, MA 18208', 94782877, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (52, 'Matthew Payne', '310 Lee Cliff Apt. 587
West Roy, PR 65695', 92156504, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (53, 'Tamara Walker DDS', '19308 Manning Parkways Apt. 745
North Angelashire, MD 20355', 96235083, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (54, 'Emily Diaz', '95737 Valdez Stream Suite 735
North Johnport, WI 50901', 99465958, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (55, 'Michele Adams', '6179 Herrera Port Apt. 149
Lake Mary, TN 89426', 50017738, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (56, 'Anthony Ramos', '1500 Dustin Square
Brittanyshire, AS 59749', 51209444, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (57, 'Jeffery Lane', '585 Kristen Ridge Suite 782
New Garymouth, HI 62696', 61647056, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (58, 'Steven Gray', 'PSC 2463, Box 0373
APO AP 65748', 81260195, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (59, 'Jason Wall', '371 Griffin Dam Suite 273
Port Jamesberg, FM 27316', 34727126, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (60, 'Teresa Moore', '8108 Moore Locks Suite 046
New Christina, RI 81610', 33026583, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (61, 'Jesse Jones', '996 Price Forges
New Xavierborough, TN 00937', 71300766, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (62, 'Michelle Miller', '1508 Richards Crest
New Virginiachester, ME 84463', 51543294, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (63, 'Nichole Peters', '613 Jones Ports Apt. 835
Oliviafurt, NM 72662', 73708700, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (64, 'Brandy Weaver', '44258 Jonathon Court Suite 629
South Robertstad, WI 21280', 62479519, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (65, 'Erica Hernandez', '99023 Joseph Rue
Port Molly, VI 71770', 70785132, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (66, 'Yvonne Haley', '31378 Stephanie Islands
Tracyville, KY 97032', 14652263, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (67, 'Vanessa Lang', '3422 Margaret Keys
Williamshire, FM 63661', 65717136, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (68, 'Michele Sawyer', '78621 Griffith Mission Suite 410
South Bethside, PW 16041', 48366368, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (69, 'Kevin Perez', '257 Michael Lake Suite 243
East Williamhaven, MD 26588', 34159808, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (70, 'Melissa Peters', '25063 Hughes Islands Suite 961
West Davidville, VT 36223', 98825309, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (71, 'Tyler Hill', '1404 Lopez Coves Suite 533
Jeremytown, DE 02935', 22389176, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (72, 'Levi Jordan', '674 Rodriguez Mission
Smithtown, OR 34153', 15372187, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (73, 'Lynn Mitchell', '11020 Carr Stream
Crystalland, DE 29387', 66488392, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (74, 'Michael Mullins', '9977 Tran Crossing
Evantown, VA 76271', 18303433, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (75, 'Beverly Briggs', '88193 Jean Lodge
South Lisa, CO 26997', 29588937, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (76, 'Dominique Pham', '32689 Kidd Court
Lozanoville, VI 98871', 81312969, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (77, 'Brandy Rivera', '425 Barnes Key
Christinahaven, AL 00730', 70129462, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (78, 'Mackenzie Dougherty', '7643 Katelyn Hollow
Gregorymouth, NM 60414', 96541732, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (79, 'Diana Casey', 'Unit 2506 Box 4612
DPO AA 32796', 35835813, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (80, 'Leah Norman', '534 Wright Dam Suite 907
Susanfurt, KS 70113', 98191768, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (81, 'Melissa Walker', 'PSC 9247, Box 6908
APO AE 07252', 22220808, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (82, 'Tyler Hernandez', 'USS Crawford
FPO AP 55612', 76365898, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (83, 'Henry Thompson', '35529 Katie Alley Apt. 546
Brandyton, KS 42070', 81707840, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (84, 'Greg Smith', '632 Peter Fords Suite 560
Lake Leslieburgh, MT 76074', 81356152, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (85, 'Jennifer Scott', '1335 Sullivan Pines Suite 218
Matthewshire, OH 85589', 11975020, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (86, 'Kimberly Reyes', '702 Glenn Walk
Cervantesfort, VI 87527', 51320557, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (87, 'John Barrett', '640 John Highway Apt. 940
Port Sharon, KY 23865', 83194376, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (88, 'Miss Emily Cook DVM', 'USS Evans
FPO AP 21846', 87018086, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (89, 'Peter Sanders', '4448 Martin Centers
Blairburgh, UT 74818', 51675614, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (90, 'Jack Sanders', '997 Khan Lights Suite 946
East Judyfurt, MH 62718', 34085085, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (91, 'Jim Coleman', '31648 Mary Extensions
Holmesfort, SC 74275', 95660212, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (92, 'John Gilbert', '3226 Stephen Stravenue Suite 853
Lake Melissa, PA 24611', 83181979, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (93, 'Kimberly Rogers', '84728 Richard Island
Port Jason, GU 26006', 34239810, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (94, 'Melissa Garrett', '35817 Carrie Vista
Bradleychester, DE 42267', 33060806, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (95, 'Lance Mills', '65647 Black Station
West Zachary, MT 55430', 91559358, 2);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (96, 'Stephen Medina', '89896 Michael Run
New Lawrence, MO 65283', 14243088, 4);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (97, 'Kevin Wallace', 'USCGC Alexander
FPO AP 04061', 54136817, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (98, 'Jordan Watson', '5149 Brooks Summit
South Jason, AZ 63971', 95374548, 3);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (99, 'Joseph Smith', 'Unit 2441 Box 3089
DPO AP 47852', 32117100, 1);
INSERT INTO clientes (id, nombre, direccion, rif, ciudad_id) VALUES (100, 'Andrew Le', '6995 Dean Ports
Marshallborough, WY 76504', 28788927, 4);
