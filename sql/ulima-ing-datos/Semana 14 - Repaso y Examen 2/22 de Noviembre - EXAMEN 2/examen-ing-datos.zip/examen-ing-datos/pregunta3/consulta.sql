SELECT 
	foots.name AS 'pie',
	COUNT(*) AS 'cantidad'
FROM players LEFT JOIN foots ON players.foot_id = foots.id
		LEFT JOIN positions ON players.position_id = positions.id
		LEFT JOIN teams ON players.team_id = teams.id
		LEFT JOIN leagues ON teams.league_id = leagues.id
		LEFT JOIN nations ON players.nation_id = nations.id
		LEFT JOIN sexs ON players.sex_id = sexs.id
WHERE sexs.id = 2 AND nations.name LIKE 'spain'
GROUP BY foots.id

