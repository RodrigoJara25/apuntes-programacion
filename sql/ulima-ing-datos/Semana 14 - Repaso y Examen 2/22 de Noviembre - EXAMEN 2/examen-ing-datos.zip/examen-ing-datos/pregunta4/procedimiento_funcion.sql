-- FUNCIONES Y PROCEDIMIENTOS

SET serveroutput on

-- Procedimiento : estructura basica

-- 1) Crear el procedimiento
CREATE OR REPLACE PROCEDURE llenar_reporte
IS
    CURSOR ligas IS
        SELECT 
            leagues.name,
            leagues.id
        FROM leagues;
    
    promedios_ligas NUMBER := 0;
    i NUMBER := 0;
    nombre_liga VARCHAR2(50) := 'cualquiera';
BEGIN

    LOOP
        IF i < 57 THEN
            FOR liga IN ligas LOOP
                IF liga.id = (i+1) THEN
                    nombre_liga := liga.name;
                END IF;
            END LOOP;
            promedios_ligas := calcular_liga_promedio(i+1);
            INSERT INTO reportes (id, league, overall) VALUES (i+1, nombre_liga, promedios_ligas);
            i := i + 1;
        ELSE
            EXIT;
        END IF;
    END LOOP;
    
END llenar_reporte;

-- 2) Ejecutar procedimeinto
-- 3) Comprobar que ha sido creada


-- Funcion : estructura basica

-- 1) Crear la funcion : devuelve las veces que un ejercicio se encuentra en la tabla ejercicios_rutinas
CREATE OR REPLACE FUNCTION calcular_liga_promedio(league_id_buscar NUMBER)
RETURN NUMBER
IS
    CURSOR promedios IS
        SELECT 
            
            AVG(common_details.overall) as promedio
        FROM players LEFT JOIN common_details ON players.id = common_details.player_id
            LEFT JOIN teams ON players.team_id = teams.id
            LEFT JOIN leagues ON teams.league_id = leagues.id
        WHERE leagues.id = league_id_buscar
        GROUP BY leagues.name;
BEGIN
    FOR liga IN promedios LOOP
        RETURN liga.promedio;
    END LOOP;
    RETURN 0;
END calcular_liga_promedio;

-- 2) Ejecutar funcion
-- 3) Comprobar que ha sido creada





