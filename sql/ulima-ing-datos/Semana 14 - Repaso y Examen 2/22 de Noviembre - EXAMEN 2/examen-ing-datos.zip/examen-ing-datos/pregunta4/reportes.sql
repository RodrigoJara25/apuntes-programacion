CREATE TABLE reportes(
  id NUMBER(7) PRIMARY KEY,
  league VARCHAR2(50),
  overall FLOAT,
  created TIMESTAMP
);

ALTER TABLE reportes ADD (
  CONSTRAINT reportes_pk PRIMARY KEY (ID));

CREATE SEQUENCE reportes_seq START WITH 1;

CREATE OR REPLACE TRIGGER reportes_pk 
BEFORE INSERT ON reportes 
FOR EACH ROW

BEGIN
  SELECT reportes_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/
