SELECT 
	players.name,
	players.age,
	players.heigth,
	players.weight,
	players.weight/((players.heigth/100.0)*(players.heigth/100.0)) AS 'IMC',
	foots.name AS 'foot',
	positions.name AS 'position',
	teams.name AS 'team',
	leagues.name AS 'league'
FROM players LEFT JOIN foots ON players.foot_id = foots.id
		LEFT JOIN positions ON players.position_id = positions.id
		LEFT JOIN teams ON players.team_id = teams.id
		LEFT JOIN leagues ON teams.league_id = leagues.id
		LEFT JOIN nations ON players.nation_id = nations.id
WHERE nations.name = 'Peru' AND 'IMC' > 30;