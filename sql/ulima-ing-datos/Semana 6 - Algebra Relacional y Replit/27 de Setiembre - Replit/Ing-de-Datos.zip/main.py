from bottle import route, run, template, static_file
from configs.database import Database    #importamos la clase "Database"

# para usar los archvios dentro de la carpeta "static" (css, imagenes, etc) y
# para usar la carpeta "static" sin tener que usar todo el rato ./static
@route('/<filename>')
def server_static(filename):
    return static_file(filename, root='./static')

# decoratiors: son como envoltorios que envuelven a la funcion
# es de la libreria bottle
@route('/')
def home():
  db = Database()
  rs = db.fetchall('SELECT * FROM pokemons')    # le respuesta de la consulta la almacenamos (la tabla)
  # Comprobar si la consulta es correcta
  #if rs is not None:
  #  # Recorremos cada fila
  #  for row in rs:
  #    # Imprimimos cada fila
  #    print(str(row['id']) + ' ' + row['name'])
  
  nombre2 = 'ppp'
  edad = 20
  return template('index', nombre = nombre2, edad = edad, pokemones = rs)

# Con @route podemos crear muchas direcciones
@route('/contacto')
def contacto():
  return template('contacto')

# esta es la funcion main
# a su vez ejecuta una funcion "run" de una libreria
if __name__ == '__main__':
  run(host='localhost', port=8080, reloader=True)

